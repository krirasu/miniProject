package com.cg.bhr.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.bhr.bean.Hotel;
import com.cg.bhr.exception.BookingException;
import com.cg.bhr.util.DBUtil;

public class HotelDaoImpl implements HotelDao 
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	public HotelDaoImpl()
	{
		
	}
	@Override
	public ArrayList<Hotel> getAllHotels() throws BookingException
	{
		ArrayList<Hotel> hotelList=new ArrayList<Hotel>();
		String selectQry="SELECT * FROM hotel";
		Hotel h = null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				h=new Hotel(rs.getString("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per-night"),rs.getString("phone_no1"),rs.getString("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getString("fax"));
				hotelList.add(h);
			}
		}
		catch (Exception e)
		{
			throw new BookingException("Problem in select");
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (SQLException e) 
			{
				throw new BookingException(e.getMessage());
			}
		}
		return hotelList;
	}
	@Override
	public ArrayList<Hotel> searchAllHotels(String hotelName)
			throws BookingException {
		
		ArrayList<Hotel> hotelList1= new ArrayList<Hotel>();
		String searchQry="SELECT * FROM hotel WHERE hotel_name=?";
		Hotel hSearch = null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(searchQry);
			pst.setString(1,hotelName);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hSearch=new Hotel(rs.getString("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per-night"),rs.getString("phone_no1"),rs.getString("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getString("fax"));
				hotelList1.add(hSearch);
			}
		}
		catch (Exception e)
		{
			throw new BookingException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				pst.close();
			} 
			catch (SQLException e) 
			{
				throw new BookingException(e.getMessage());
			}
		}
		return hotelList1;
	}
}
