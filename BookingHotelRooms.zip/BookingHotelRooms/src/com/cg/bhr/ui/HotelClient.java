package com.cg.bhr.ui;
import java.util.ArrayList;
import java.util.Scanner;
import com.cg.bhr.bean.Hotel;
import com.cg.bhr.exception.BookingException;
import com.cg.bhr.service.HotelService;
import com.cg.bhr.service.HotelServiceImpl;

public class HotelClient 
{
	static Scanner sc=null;
	static HotelService hotelSer=null;

	public static void main(String[] args) 
	{
		hotelSer=new HotelServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to perform?");
			System.out.println("1.View All Hotels");
			System.out.println("2.Search All Hotels");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:viewAllHotels();
			break;
			case 2: searchAllHotels();
			break;
			}
		}

	}

	private static void viewAllHotels() 
	{
		try
		{
			ArrayList<Hotel> hotelList=hotelSer.getAllHotels();
			for(Hotel ee:hotelList)
			{
				System.out.println(ee);
			}
		}
		catch (BookingException e) 
		{
			System.out.println("Some exception occured while fetching");
			e.printStackTrace();
		}
	}
	
	private static void searchAllHotels() 
	{
		System.out.println("Enter hotel Name");
		String hName=sc.next();
		try
		{
			ArrayList<Hotel> hList= hotelSer.searchAllHotels(hName);
			
			for(Hotel hh:hList)
			{
				System.out.println(hh);
			}
		}
	catch (BookingException e)
	{
		System.out.println(e.getMessage());
	}
	}	
}


